// AppliedIn - LinkedIn Content Script
// Captures ONLY on final submission confirmation.
// The Easy Apply modal can obscure/replace the underlying job title and
// company elements once it's open, so we cache those details the moment
// "Easy Apply" is clicked — while the job card is still visible — and use
// that cached data at submission time instead of re-scraping the modal.

(function () {
  console.log('[AppliedIn] linkedin.js loaded on', window.location.href);

  function extractSalary() {
    const selectors = [
      '[class*="salary"]', '[class*="ctc"]', '[class*="stipend"]',
      '[data-testid*="salary"]', '[class*="compensation"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText.trim()) return el.innerText.trim();
    }
    // Regex scan for salary patterns in page text
    const match = (document.body.innerText || '').match(
      /(₹[\d,]+\s*(?:LPA|lpa|L|k|\/month|per month|stipend)?[\s\-–to]*₹?[\d,]*\s*(?:LPA|lpa|L|k)?)/
    );
    return match ? match[1].trim() : '';
  }

  function extractJobType() {
    const text = (document.body.innerText || '').toLowerCase();
    if (text.includes('internship')) return 'Internship';
    if (text.includes('full-time') || text.includes('full time')) return 'Full-Time';
    if (text.includes('part-time') || text.includes('part time')) return 'Part-Time';
    if (text.includes('contract')) return 'Contract';
    if (text.includes('freelance')) return 'Freelance';
    return '';
  }

  function extractWorkMode() {
    const text = (document.body.innerText || '').toLowerCase();
    if (text.includes('work from home') || text.includes('remote')) return 'Remote';
    if (text.includes('hybrid')) return 'Hybrid';
    return 'On-site';
  }


  // Tracks the URL we already handled — prevents re-asking on every
  // subsequent DOM mutation once a success message is showing.
  let lastHandledUrl = null;
  // FIX BUG 2: Use a tab-unique pending key so two tabs (e.g. LinkedIn + Naukri)
  // never overwrite each other's cached job data.
  // performance.now() gives microsecond precision unique to each tab's page load.
  const PENDING_KEY = 'appliedin_pending_' + Math.round(performance.now() * 1000);
  const PENDING_MAX_AGE_MS = 30 * 60 * 1000; // 30 minutes

  // LinkedIn's tab title reliably follows "Job Title | Company | LinkedIn"
  // — much more stable than CSS class names, which change frequently.
  function getDetailsFromTabTitle() {
    const parts = (document.title || '').split('|').map(p => p.trim()).filter(Boolean);
    // parts[0] = role, parts[1] = company, parts[last] usually "LinkedIn"
    if (parts.length >= 2) {
      return { role: parts[0], company: parts[1] };
    }
    return { role: null, company: null };
  }

  function getJobDetails() {
    try {
      const tabTitle = getDetailsFromTabTitle();

      const title =
        document.querySelector('.job-details-jobs-unified-top-card__job-title h1')?.innerText?.trim() ||
        document.querySelector('h1.t-24')?.innerText?.trim() ||
        document.querySelector('h1')?.innerText?.trim() ||
        tabTitle.role ||
        'Unknown Role';

      const company =
        document.querySelector('.job-details-jobs-unified-top-card__company-name a')?.innerText?.trim() ||
        document.querySelector('.job-details-jobs-unified-top-card__company-name')?.innerText?.trim() ||
        document.querySelector('a[href*="/company/"]')?.innerText?.trim() ||
        tabTitle.company ||
        'Unknown Company';

      const location =
        document.querySelector('.job-details-jobs-unified-top-card__bullet')?.innerText?.trim() ||
        'Unknown Location';

      return {
        company,
        role: title,
        location,
        salary: extractSalary(),
        jobType: extractJobType(),
        workMode: extractWorkMode(),
        platform: 'LinkedIn',
        url: window.location.href,
        date: new Date().toISOString(),
        status: 'Applied'
      };
    } catch (e) {
      console.log('[AppliedIn] getJobDetails threw:', e);
      // Last-resort fallback: try the tab title one more time before
      // giving up completely.
      const tabTitle = getDetailsFromTabTitle();
      return {
        company: tabTitle.company || 'Unknown Company',
        role: tabTitle.role || 'Unknown Role',
        location: 'Unknown Location',
        platform: 'LinkedIn',
        url: window.location.href,
        date: new Date().toISOString(),
        status: 'Applied'
      };
    }
  }

  // Stricter version used ONLY for caching — we don't want to cache
  // "Unknown Company" as if it were reliable data.
  function getJobDetailsForCaching() {
    const jobData = getJobDetails();
    if (jobData.company === 'Unknown Company' || jobData.role === 'Unknown Role') return null;
    return jobData;
  }

  const successPhrases = [
    'your application was sent',
    'application submitted',
    'you\'ve applied',
    'application was sent to',
    'successfully applied'
  ];

  function cachePendingJob(jobData) {
    chrome.storage.local.set({
      [PENDING_KEY]: { jobData, timestamp: Date.now() }
    });
  }

  function getPendingJob(callback) {
    chrome.storage.local.get([PENDING_KEY], function (result) {
      const entry = result[PENDING_KEY];
      if (entry && (Date.now() - entry.timestamp) < PENDING_MAX_AGE_MS) {
        callback(entry.jobData);
      } else {
        callback(null);
      }
    });
  }

  function saveApplication(jobData) {
    window.__appliedinCommon.saveApplication(jobData, function () {
      // duplicate — this URL stays marked as handled, no re-prompt
    }, function () {
      // saved — this URL stays marked as handled, no re-prompt
      chrome.storage.local.remove(PENDING_KEY);
    });
  }


  // Guard: if confirm popup already open (user typing), skip — don't interrupt.
  function isPopupOpen() {
    return !!document.getElementById('appliedin-confirm');
  }
  function bodyLooksLikeSuccess() {
    const bodyText = (document.body.innerText || '').toLowerCase();
    return successPhrases.some(p => bodyText.includes(p));
  }

  function handleSuccess() {
    if (lastHandledUrl === window.location.href) return;
    lastHandledUrl = window.location.href;

    getPendingJob(function (pendingJob) {
      const jobData = pendingJob || getJobDetails();
      console.log('[AppliedIn] jobData for save:', jobData);

      if (jobData && jobData.company && jobData.company !== 'Unknown Company') {
        saveApplication(jobData);
      } else if (jobData) {
        window.__appliedinCommon.showConfirmPopup(jobData, 'LinkedIn', function () {
          // user answered — this URL stays marked as handled
        });
      } else {
        lastHandledUrl = null;
      }
    });
  }

  document.addEventListener('click', function (e) {
    const button = e.target.closest('button');
    if (!button) return;

    const text = button.innerText?.trim().toLowerCase();
    if (!text) return;

    // "Easy Apply" just opens the modal — cache the real job details now,
    // while the underlying job card is still visible and readable.
    if (text === 'easy apply') {
      const jobData = getJobDetailsForCaching();
      if (jobData) cachePendingJob(jobData);
      return;
    }

    // Only capture on FINAL submit — not on "Next"/"Review"
    if (
      text === 'submit application' ||
      text === 'submit' ||
      text === 'done'
    ) {
      if (lastHandledUrl === window.location.href) return;

      setTimeout(() => {
        if (bodyLooksLikeSuccess()) {
          handleSuccess();
        }
      }, 2000);
    }
  });

  // Watch for success confirmation message in DOM
  const observer = new MutationObserver(function () {
    if (lastHandledUrl === window.location.href) return;
    if (isPopupOpen()) return;
    if (bodyLooksLikeSuccess()) {
      setTimeout(handleSuccess, 1000);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

})();
